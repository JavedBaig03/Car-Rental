const carData = [
    { id: 1, image: "/assets/images/sedan.jpg", name: "Sedan", price: "$50/day", capacity: "4 persons" },
    { id: 2, image: "/assets/images/suv.jpg", name: "SUV", price: "$80/day", capacity: "7 persons" },
    { id: 3, image: "/assets/images/convertible.jpg", name: "Convertible", price: "$120/day", capacity: "2 persons" },
  ];
  
  export default carData;
  